import { Heart, Home, HelpCircle, MessageSquareText, Layers, Layout, Pill, Calendar, BookOpen } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Navbar() {
  return (
    <nav className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center space-x-2">
              <Heart className="h-8 w-8 text-rose-600" />
              <span className="text-xl font-semibold text-gray-900">AI Patient Advocate</span>
            </Link>
          </div>
          <div className="flex items-center space-x-4">
            <Link to="/" className="flex items-center space-x-1 text-gray-700 hover:text-rose-600">
              <Home className="h-5 w-5" />
              <span>Home</span>
            </Link>
            <Link to="/dashboard" className="flex items-center space-x-1 text-gray-700 hover:text-rose-600">
              <Layout className="h-5 w-5" />
              <span>Dashboard</span>
            </Link>
            <Link to="/medications" className="flex items-center space-x-1 text-gray-700 hover:text-rose-600">
              <Pill className="h-5 w-5" />
              <span>Medications</span>
            </Link>
            <Link to="/appointments" className="flex items-center space-x-1 text-gray-700 hover:text-rose-600">
              <Calendar className="h-5 w-5" />
              <span>Appointments</span>
            </Link>
            <Link to="/journal" className="flex items-center space-x-1 text-gray-700 hover:text-rose-600">
              <BookOpen className="h-5 w-5" />
              <span>Journal</span>
            </Link>
            <Link to="/advocate" className="flex items-center space-x-1 text-gray-700 hover:text-rose-600">
              <MessageSquareText className="h-5 w-5" />
              <span>Get Help</span>
            </Link>
            <Link to="/channels" className="flex items-center space-x-1 text-gray-700 hover:text-rose-600">
              <Layers className="h-5 w-5" />
              <span>Channels</span>
            </Link>
            <Link to="/faq" className="flex items-center space-x-1 text-gray-700 hover:text-rose-600">
              <HelpCircle className="h-5 w-5" />
              <span>FAQ</span>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}