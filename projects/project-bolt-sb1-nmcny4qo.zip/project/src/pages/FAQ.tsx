import { Minus, Plus } from 'lucide-react';
import { useState } from 'react';

const faqs = [
  {
    question: "How can AI Patient Advocate help me?",
    answer: "Our AI system helps you understand medical terms, prepare for appointments, manage healthcare costs, and navigate insurance. It provides personalized health guidance and helps you make informed decisions about your healthcare."
  },
  {
    question: "Is my health information secure?",
    answer: "Yes, we take your privacy seriously. All your information is encrypted and stored securely. We comply with HIPAA regulations and never share your personal health information without your explicit consent."
  },
  {
    question: "Can this replace my doctor?",
    answer: "No, AI Patient Advocate is not a replacement for professional medical care. It's a tool to help you better understand and manage your healthcare journey, communicate effectively with your healthcare providers, and make informed decisions."
  },
  {
    question: "How do I get started?",
    answer: "Simply click on the 'Get Help' button and start describing your needs. Our AI will guide you through the process and provide relevant information and support based on your specific situation."
  },
  {
    question: "What if I need immediate medical attention?",
    answer: "If you're experiencing a medical emergency, please call 911 or go to the nearest emergency room immediately. Our service is not designed for emergency situations."
  }
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-8">
          Frequently Asked Questions
        </h2>
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div key={index} className="bg-white rounded-lg shadow-sm">
              <button
                className="w-full px-4 py-5 flex justify-between items-center focus:outline-none"
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
              >
                <span className="text-lg font-medium text-gray-900">{faq.question}</span>
                {openIndex === index ? (
                  <Minus className="h-5 w-5 text-gray-500" />
                ) : (
                  <Plus className="h-5 w-5 text-gray-500" />
                )}
              </button>
              {openIndex === index && (
                <div className="px-4 pb-5">
                  <p className="text-gray-500">{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}