import { Plus, Search, Clock, CheckCircle, AlertCircle } from 'lucide-react';

export default function Medications() {
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Medications</h1>
          <button className="flex items-center px-4 py-2 bg-rose-600 text-white rounded-md hover:bg-rose-700">
            <Plus className="h-5 w-5 mr-2" />
            Add Medication
          </button>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search medications..."
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-rose-500 focus:border-rose-500"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Active Medications */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-xl font-semibold mb-4">Active Medications</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 border rounded-md">
                <div>
                  <h3 className="font-medium">Medication A</h3>
                  <p className="text-sm text-gray-500">10mg - Once daily</p>
                </div>
                <div className="flex items-center">
                  <Clock className="h-5 w-5 text-gray-400 mr-2" />
                  <span className="text-sm">Next: 8:00 PM</span>
                </div>
              </div>
              <div className="flex items-center justify-between p-4 border rounded-md">
                <div>
                  <h3 className="font-medium">Medication B</h3>
                  <p className="text-sm text-gray-500">25mg - Twice daily</p>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-sm">Taken</span>
                </div>
              </div>
            </div>
          </div>

          {/* Medication History */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-xl font-semibold mb-4">Medication History</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 border rounded-md">
                <div>
                  <h3 className="font-medium">Medication C</h3>
                  <p className="text-sm text-gray-500">Completed course</p>
                </div>
                <span className="text-sm text-gray-500">Ended 2 weeks ago</span>
              </div>
              <div className="flex items-center justify-between p-4 border rounded-md">
                <div>
                  <h3 className="font-medium">Medication D</h3>
                  <p className="text-sm text-gray-500">Discontinued</p>
                </div>
                <div className="flex items-center">
                  <AlertCircle className="h-5 w-5 text-yellow-500 mr-2" />
                  <span className="text-sm">Side effects reported</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}