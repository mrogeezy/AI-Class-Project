import { Activity, Calendar, Pill as Pills, BookOpen, Bell, TrendingUp } from 'lucide-react';
import { format } from 'date-fns';

export default function Dashboard() {
  const today = new Date();

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Welcome Back, User</h1>
          <p className="text-gray-600">{format(today, 'EEEE, MMMM d, yyyy')}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Quick Actions */}
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
            <div className="space-y-4">
              <button className="w-full flex items-center justify-between p-3 text-left rounded-md hover:bg-rose-50">
                <div className="flex items-center">
                  <Calendar className="h-5 w-5 text-rose-600 mr-3" />
                  <span>Schedule Appointment</span>
                </div>
                <span className="text-rose-600">→</span>
              </button>
              <button className="w-full flex items-center justify-between p-3 text-left rounded-md hover:bg-rose-50">
                <div className="flex items-center">
                  <Pills className="h-5 w-5 text-rose-600 mr-3" />
                  <span>Track Medication</span>
                </div>
                <span className="text-rose-600">→</span>
              </button>
              <button className="w-full flex items-center justify-between p-3 text-left rounded-md hover:bg-rose-50">
                <div className="flex items-center">
                  <BookOpen className="h-5 w-5 text-rose-600 mr-3" />
                  <span>Add Journal Entry</span>
                </div>
                <span className="text-rose-600">→</span>
              </button>
            </div>
          </div>

          {/* Upcoming Events */}
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h2 className="text-xl font-semibold mb-4">Upcoming Events</h2>
            <div className="space-y-4">
              <div className="flex items-start space-x-4">
                <div className="bg-rose-100 rounded-md p-2">
                  <Calendar className="h-5 w-5 text-rose-600" />
                </div>
                <div>
                  <p className="font-medium">Dr. Smith Appointment</p>
                  <p className="text-sm text-gray-500">Tomorrow at 10:00 AM</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="bg-rose-100 rounded-md p-2">
                  <Pills className="h-5 w-5 text-rose-600" />
                </div>
                <div>
                  <p className="font-medium">Medication Refill</p>
                  <p className="text-sm text-gray-500">In 3 days</p>
                </div>
              </div>
            </div>
          </div>

          {/* Health Stats */}
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h2 className="text-xl font-semibold mb-4">Health Stats</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Activity className="h-5 w-5 text-rose-600" />
                  <span>Heart Rate</span>
                </div>
                <span className="font-medium">72 bpm</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <TrendingUp className="h-5 w-5 text-rose-600" />
                  <span>Blood Pressure</span>
                </div>
                <span className="font-medium">120/80</span>
              </div>
            </div>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="mt-8 bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-xl font-semibold mb-4">Recent Activity</h2>
          <div className="space-y-4">
            <div className="flex items-start space-x-4">
              <div className="bg-rose-100 rounded-md p-2">
                <Bell className="h-5 w-5 text-rose-600" />
              </div>
              <div>
                <p className="font-medium">Medication Reminder</p>
                <p className="text-sm text-gray-500">Took evening medication</p>
                <p className="text-xs text-gray-400">2 hours ago</p>
              </div>
            </div>
            <div className="flex items-start space-x-4">
              <div className="bg-rose-100 rounded-md p-2">
                <BookOpen className="h-5 w-5 text-rose-600" />
              </div>
              <div>
                <p className="font-medium">Journal Entry Added</p>
                <p className="text-sm text-gray-500">Updated symptoms log</p>
                <p className="text-xs text-gray-400">Yesterday</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}