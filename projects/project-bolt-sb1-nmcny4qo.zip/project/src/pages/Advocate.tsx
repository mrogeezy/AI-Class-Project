import { useState } from 'react';
import { MessageSquare, Send } from 'lucide-react';

type Category = 'health' | 'appointments' | 'insurance' | 'billing' | '';

export default function Advocate() {
  const [category, setCategory] = useState<Category>('');
  const [query, setQuery] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission here
    console.log('Category:', category);
    console.log('Query:', query);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center space-x-3 mb-6">
            <MessageSquare className="h-8 w-8 text-rose-600" />
            <h2 className="text-2xl font-bold text-gray-900">
              How can I help you today?
            </h2>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Select a category:
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as Category)}
                className="w-full rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white focus:outline-none focus:ring-2 focus:ring-rose-500 focus:border-rose-500"
              >
                <option value="">Select a category</option>
                <option value="health">Health Information & Guidance</option>
                <option value="appointments">Appointment Preparation</option>
                <option value="insurance">Insurance Navigation</option>
                <option value="billing">Billing & Costs</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                How can I assist you?
              </label>
              <textarea
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                rows={4}
                className="w-full rounded-md border border-gray-300 shadow-sm px-4 py-2 focus:outline-none focus:ring-2 focus:ring-rose-500 focus:border-rose-500"
                placeholder="Describe your needs or questions..."
              />
            </div>

            <button
              type="submit"
              className="w-full flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-white bg-rose-600 hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-rose-500"
            >
              <Send className="h-5 w-5 mr-2" />
              Get Assistance
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}