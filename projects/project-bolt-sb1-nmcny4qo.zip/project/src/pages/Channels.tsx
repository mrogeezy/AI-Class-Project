import { Smartphone, Watch, Globe, Laptop } from 'lucide-react';

export default function Channels() {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900">Access Your Health Advocate Anywhere</h1>
          <p className="mt-4 text-xl text-gray-600">Connect with your AI health advocate across all your devices</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Web Platform */}
          <div className="bg-white p-8 rounded-lg shadow-sm border border-gray-100">
            <div className="flex items-center justify-center h-16 w-16 rounded-full bg-rose-100 text-rose-600 mx-auto">
              <Globe className="h-8 w-8" />
            </div>
            <h3 className="mt-6 text-xl font-semibold text-center text-gray-900">Web Platform</h3>
            <p className="mt-4 text-gray-600 text-center">
              Access your health advocate from any browser. Get comprehensive support and detailed insights on our web platform.
            </p>
          </div>

          {/* Mobile App */}
          <div className="bg-white p-8 rounded-lg shadow-sm border border-gray-100">
            <div className="flex items-center justify-center h-16 w-16 rounded-full bg-rose-100 text-rose-600 mx-auto">
              <Smartphone className="h-8 w-8" />
            </div>
            <h3 className="mt-6 text-xl font-semibold text-center text-gray-900">Mobile App</h3>
            <p className="mt-4 text-gray-600 text-center">
              Take your health advocate with you. Available for iOS and Android devices with real-time notifications and updates.
            </p>
          </div>

          {/* Wearables */}
          <div className="bg-white p-8 rounded-lg shadow-sm border border-gray-100">
            <div className="flex items-center justify-center h-16 w-16 rounded-full bg-rose-100 text-rose-600 mx-auto">
              <Watch className="h-8 w-8" />
            </div>
            <h3 className="mt-6 text-xl font-semibold text-center text-gray-900">Wearable Integration</h3>
            <p className="mt-4 text-gray-600 text-center">
              Connect with Apple Watch, Fitbit, and other wearables for real-time health monitoring and instant feedback.
            </p>
          </div>
        </div>

        {/* Integration Partners */}
        <div className="mt-20">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Trusted by Industry Leaders</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
              <h3 className="text-xl font-semibold text-center text-gray-900 mb-4">Google Health</h3>
              <p className="text-gray-600 text-center">
                Integrating with Google Health to provide comprehensive health data analysis and insights.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
              <h3 className="text-xl font-semibold text-center text-gray-900 mb-4">OpenAI</h3>
              <p className="text-gray-600 text-center">
                Powered by advanced AI technology to deliver personalized health guidance and support.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100">
              <h3 className="text-xl font-semibold text-center text-gray-900 mb-4">Health Advocacy Groups</h3>
              <p className="text-gray-600 text-center">
                Partnering with leading advocacy organizations to ensure comprehensive patient support.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}