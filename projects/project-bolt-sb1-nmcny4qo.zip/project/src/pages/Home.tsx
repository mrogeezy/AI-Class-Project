import { ArrowRight, Brain, Calendar, FileText, HeartPulse, Shield } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-white">
        <div className="max-w-7xl mx-auto px-4 py-16 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 sm:text-5xl md:text-6xl">
              Your AI Health Advocate
            </h1>
            <p className="mt-3 max-w-md mx-auto text-base text-gray-500 sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
              Empowering patients with personalized healthcare guidance, simplified medical information, and advocacy support.
            </p>
            <div className="mt-5 max-w-md mx-auto sm:flex sm:justify-center md:mt-8">
              <Link
                to="/advocate"
                className="flex items-center justify-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-rose-600 hover:bg-rose-700 md:py-4 md:text-lg md:px-10"
              >
                Get Started
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
            <div className="p-6 bg-white rounded-lg shadow-sm border border-gray-100">
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-rose-100 text-rose-600">
                <Brain className="h-6 w-6" />
              </div>
              <h3 className="mt-4 text-lg font-medium text-gray-900">Health Education</h3>
              <p className="mt-2 text-gray-500">Clear explanations of medical terms and conditions in simple language.</p>
            </div>

            <div className="p-6 bg-white rounded-lg shadow-sm border border-gray-100">
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-rose-100 text-rose-600">
                <Calendar className="h-6 w-6" />
              </div>
              <h3 className="mt-4 text-lg font-medium text-gray-900">Appointment Prep</h3>
              <p className="mt-2 text-gray-500">Get ready for doctor visits with personalized question lists and reminders.</p>
            </div>

            <div className="p-6 bg-white rounded-lg shadow-sm border border-gray-100">
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-rose-100 text-rose-600">
                <Shield className="h-6 w-6" />
              </div>
              <h3 className="mt-4 text-lg font-medium text-gray-900">Insurance Navigation</h3>
              <p className="mt-2 text-gray-500">Understanding your coverage and managing healthcare costs.</p>
            </div>

            <div className="p-6 bg-white rounded-lg shadow-sm border border-gray-100">
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-rose-100 text-rose-600">
                <HeartPulse className="h-6 w-6" />
              </div>
              <h3 className="mt-4 text-lg font-medium text-gray-900">Health Monitoring</h3>
              <p className="mt-2 text-gray-500">Track symptoms and get personalized health recommendations.</p>
            </div>

            <div className="p-6 bg-white rounded-lg shadow-sm border border-gray-100">
              <div className="flex items-center justify-center h-12 w-12 rounded-md bg-rose-100 text-rose-600">
                <FileText className="h-6 w-6" />
              </div>
              <h3 className="mt-4 text-lg font-medium text-gray-900">Document Management</h3>
              <p className="mt-2 text-gray-500">Organize and understand your medical records and bills.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Partners Section */}
      <div className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">Powered by Industry Leaders</h2>
            <p className="mt-4 text-xl text-gray-600">
              We're partnering with leading technology and healthcare organizations
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold text-center mb-4">Google Health Partnership</h3>
              <p className="text-gray-600 text-center">
                Leveraging Google Health's advanced healthcare APIs for comprehensive health tracking and insights.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold text-center mb-4">OpenAI Technology</h3>
              <p className="text-gray-600 text-center">
                Using cutting-edge AI models to provide intelligent health guidance and support.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold text-center mb-4">Advocacy Network</h3>
              <p className="text-gray-600 text-center">
                Working with leading patient advocacy groups to ensure comprehensive support for all users.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}