import { Plus, Search, Calendar, Tag } from 'lucide-react';
import { format } from 'date-fns';

export default function HealthJournal() {
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Health Journal</h1>
          <button className="flex items-center px-4 py-2 bg-rose-600 text-white rounded-md hover:bg-rose-700">
            <Plus className="h-5 w-5 mr-2" />
            New Entry
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Journal Entries */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <Calendar className="h-5 w-5 text-gray-400" />
                  <span className="text-gray-500">{format(new Date(), 'MMMM d, yyyy')}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Tag className="h-5 w-5 text-rose-600" />
                  <span className="text-sm text-rose-600">Symptoms</span>
                </div>
              </div>
              <h2 className="text-xl font-semibold mb-2">Morning Check-in</h2>
              <p className="text-gray-600 mb-4">
                Feeling better today. Pain level has decreased to 3/10. Morning medication taken on schedule.
              </p>
              <div className="flex space-x-2">
                <span className="px-2 py-1 bg-rose-100 text-rose-600 rounded-md text-sm">Pain Level: 3</span>
                <span className="px-2 py-1 bg-green-100 text-green-600 rounded-md text-sm">Medication Taken</span>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <Calendar className="h-5 w-5 text-gray-400" />
                  <span className="text-gray-500">{format(new Date(), 'MMMM d, yyyy')}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Tag className="h-5 w-5 text-blue-600" />
                  <span className="text-sm text-blue-600">Activity</span>
                </div>
              </div>
              <h2 className="text-xl font-semibold mb-2">Afternoon Walk</h2>
              <p className="text-gray-600 mb-4">
                Completed a 20-minute walk. Felt energetic with no shortness of breath.
              </p>
              <div className="flex space-x-2">
                <span className="px-2 py-1 bg-blue-100 text-blue-600 rounded-md text-sm">Exercise</span>
                <span className="px-2 py-1 bg-green-100 text-green-600 rounded-md text-sm">Good Energy</span>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Search */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search journal entries..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-rose-500 focus:border-rose-500"
                />
              </div>
            </div>

            {/* Categories */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-lg font-semibold mb-4">Categories</h2>
              <div className="space-y-2">
                <button className="w-full text-left px-3 py-2 rounded-md hover:bg-rose-50 text-rose-600">
                  Symptoms (24)
                </button>
                <button className="w-full text-left px-3 py-2 rounded-md hover:bg-blue-50 text-blue-600">
                  Activity (15)
                </button>
                <button className="w-full text-left px-3 py-2 rounded-md hover:bg-green-50 text-green-600">
                  Medication (31)
                </button>
                <button className="w-full text-left px-3 py-2 rounded-md hover:bg-purple-50 text-purple-600">
                  Mood (18)
                </button>
              </div>
            </div>

            {/* Stats */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-lg font-semibold mb-4">Monthly Stats</h2>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Total Entries</span>
                  <span className="font-medium">42</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Symptoms Logged</span>
                  <span className="font-medium">15</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Activities Tracked</span>
                  <span className="font-medium">8</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}