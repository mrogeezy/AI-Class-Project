import { Plus, Calendar, Clock, MapPin, User } from 'lucide-react';
import { format } from 'date-fns';

export default function Appointments() {
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Appointments</h1>
          <button className="flex items-center px-4 py-2 bg-rose-600 text-white rounded-md hover:bg-rose-700">
            <Plus className="h-5 w-5 mr-2" />
            Schedule Appointment
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Upcoming Appointments */}
          <div className="lg:col-span-2">
            <h2 className="text-xl font-semibold mb-4">Upcoming Appointments</h2>
            <div className="space-y-4">
              <div className="bg-white p-6 rounded-lg shadow-sm">
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-4">
                    <div className="bg-rose-100 rounded-md p-2">
                      <User className="h-6 w-6 text-rose-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">Dr. Sarah Smith</h3>
                      <p className="text-sm text-gray-500">Cardiologist</p>
                      <div className="mt-2 space-y-1">
                        <div className="flex items-center text-sm text-gray-500">
                          <Calendar className="h-4 w-4 mr-2" />
                          <span>{format(new Date(), 'MMMM d, yyyy')}</span>
                        </div>
                        <div className="flex items-center text-sm text-gray-500">
                          <Clock className="h-4 w-4 mr-2" />
                          <span>10:00 AM</span>
                        </div>
                        <div className="flex items-center text-sm text-gray-500">
                          <MapPin className="h-4 w-4 mr-2" />
                          <span>123 Medical Center Dr.</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <button className="px-3 py-1 text-sm text-rose-600 border border-rose-600 rounded-md hover:bg-rose-50">
                      Reschedule
                    </button>
                    <button className="px-3 py-1 text-sm text-white bg-rose-600 rounded-md hover:bg-rose-700">
                      Prepare
                    </button>
                  </div>
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-sm">
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-4">
                    <div className="bg-rose-100 rounded-md p-2">
                      <User className="h-6 w-6 text-rose-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">Dr. Michael Johnson</h3>
                      <p className="text-sm text-gray-500">Primary Care</p>
                      <div className="mt-2 space-y-1">
                        <div className="flex items-center text-sm text-gray-500">
                          <Calendar className="h-4 w-4 mr-2" />
                          <span>{format(new Date(), 'MMMM d, yyyy')}</span>
                        </div>
                        <div className="flex items-center text-sm text-gray-500">
                          <Clock className="h-4 w-4 mr-2" />
                          <span>2:30 PM</span>
                        </div>
                        <div className="flex items-center text-sm text-gray-500">
                          <MapPin className="h-4 w-4 mr-2" />
                          <span>456 Health Plaza</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <button className="px-3 py-1 text-sm text-rose-600 border border-rose-600 rounded-md hover:bg-rose-50">
                      Reschedule
                    </button>
                    <button className="px-3 py-1 text-sm text-white bg-rose-600 rounded-md hover:bg-rose-700">
                      Prepare
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Appointment History */}
          <div>
            <h2 className="text-xl font-semibold mb-4">Past Appointments</h2>
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="space-y-4">
                <div className="border-b pb-4">
                  <p className="font-medium">Dr. Sarah Smith</p>
                  <p className="text-sm text-gray-500">Cardiologist</p>
                  <p className="text-sm text-gray-500">March 1, 2024</p>
                </div>
                <div className="border-b pb-4">
                  <p className="font-medium">Dr. Michael Johnson</p>
                  <p className="text-sm text-gray-500">Primary Care</p>
                  <p className="text-sm text-gray-500">February 15, 2024</p>
                </div>
                <div>
                  <p className="font-medium">Dr. Emily Chen</p>
                  <p className="text-sm text-gray-500">Neurologist</p>
                  <p className="text-sm text-gray-500">February 1, 2024</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}